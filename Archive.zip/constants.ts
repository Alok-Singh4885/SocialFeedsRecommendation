export const ENVIROMENT = {
    LOCAL: 'local',
    STAGE: 'staging',
    DEV: 'development',
    PROD: 'production'
  }
  